
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var ground
var gameState
function preload(){
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(500, 400);
  obstacleGroup = createGroup()
  FoodGroup = createGroup()
  monkey = createSprite(100, 364, 10, 10);
  monkey.addAnimation ("moving", monkey_running);
  monkey.scale = 0.1;
  ground = createSprite(250, 395, 500, 10);
  score = 0
  gameState = "Play"
}


function draw() {
background (245);
monkey.collide(ground);
monkey.velocityY = monkey.velocityY + 0.8
if (keyDown("space") && monkey.y >= 350) {
  monkey.velocityY = -15;
}
  
  if (frameCount % 10 === 0 && gameState === "Play") {
    score = score + 1;
  }
text("Survival Time: "+ score, 220, 50);
if (gameState === "Play") {
spawnObstacle()
spawnBanana()
}
if(obstacleGroup.isTouching(monkey)){
  gameState = "End"
}
  
if(gameState === "End") {
  monkey.velocityY = 0;
  obstacle.velocityX = 0;
  banana.velocityX = 0;
}
drawSprites();
}

function spawnObstacle(){
  if (frameCount % 300 === 0){
    obstacle = createSprite(500,361,30,30);
    obstacle.addImage (obstaceImage, "obstacle.png");
    obstacle.velocityX = -10;
    obstacle.scale = 0.15
    obstacleGroup.add(obstacle);
  }
}

function spawnBanana(){
  if (frameCount % 80 === 0){
    banana = createSprite(500,Math.round(random(350,200)),30,30);
    banana.addImage (bananaImage, "banana.png");
    banana.velocityX = -10;
    banana.scale = 0.15
    FoodGroup.add(banana);
    banana.scale = 0.1
  }
}